var searchData=
[
  ['clear_5fconfirm_5ftext',['CLEAR_CONFIRM_TEXT',['../monitorwindow_8h.html#a3a8c028008b0156c2d24a5e1bfb756a3',1,'monitorwindow.h']]],
  ['connect_5ftext',['CONNECT_TEXT',['../monitorwindow_8h.html#a344462a67f177660358a497be830cb2d',1,'monitorwindow.h']]],
  ['connected_5fto_5ftext',['CONNECTED_TO_TEXT',['../monitorwindow_8h.html#adafc8aa0a0556d1e8189d2672c009990',1,'monitorwindow.h']]]
];
