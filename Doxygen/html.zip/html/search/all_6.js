var searchData=
[
  ['issimilarsize',['isSimilarSize',['../class_monitor_window.html#a4fd23fc4d2ce5f3d0c335966c9ea8e99',1,'MonitorWindow']]],
  ['iswss',['isWss',['../class_monitor_window.html#a515c40c63c1350cf1ae56a92d7197da9',1,'MonitorWindow']]]
];
