var searchData=
[
  ['exit_5fconfirm_5ftext',['EXIT_CONFIRM_TEXT',['../monitorwindow_8h.html#a1e33a0e3fa061d829876eb24695f5cec',1,'monitorwindow.h']]]
];
