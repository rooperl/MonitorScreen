var searchData=
[
  ['resizetext',['resizeText',['../class_monitor_window.html#ad901309f83a80f3a64422e9eac36876d',1,'MonitorWindow']]]
];
