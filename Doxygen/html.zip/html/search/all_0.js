var searchData=
[
  ['app_5fname',['APP_NAME',['../monitorwindow_8h.html#acfc4dc151950061256dd932450835d29',1,'monitorwindow.h']]],
  ['autoconnect',['autoConnect',['../class_monitor_window.html#a64ef5c90aecc74e96792676a951bad69',1,'MonitorWindow']]]
];
