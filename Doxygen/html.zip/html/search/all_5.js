var searchData=
[
  ['height_5foffset',['HEIGHT_OFFSET',['../monitorwindow_8h.html#a7a37efe55570ca3e385024b172f6118f',1,'monitorwindow.h']]]
];
