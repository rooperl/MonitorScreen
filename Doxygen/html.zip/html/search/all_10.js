var searchData=
[
  ['window_5finit_5fratio',['WINDOW_INIT_RATIO',['../monitorwindow_8h.html#a4a91a9c39fb0d5063eaa13bd38b9356e',1,'monitorwindow.h']]],
  ['windowsize',['windowSize',['../class_monitor_window.html#a09b25cce0785372176a2c19546fb7df8',1,'MonitorWindow']]],
  ['ws_5furi_5ftext',['WS_URI_TEXT',['../monitorwindow_8h.html#a6356b7e4d480dba5e80275493d3648b1',1,'monitorwindow.h']]],
  ['wss_5fscheme',['WSS_SCHEME',['../monitorwindow_8h.html#ac5b30f276eefb9be166448b458a6b275',1,'monitorwindow.h']]]
];
