var searchData=
[
  ['font',['font',['../class_monitor_window.html#a9596df93cb3604a8578a84009d88f549',1,'MonitorWindow']]]
];
