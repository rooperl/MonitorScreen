var searchData=
[
  ['selectedparameter',['selectedParameter',['../class_monitor_window.html#a5dd079ac7b5cc6a78c0706d03eed57d5',1,'MonitorWindow']]],
  ['settings',['settings',['../class_monitor_window.html#a62cea8741de13302ee0b896488c8343e',1,'MonitorWindow']]],
  ['size_5fdiff_5ftolerance',['SIZE_DIFF_TOLERANCE',['../monitorwindow_8h.html#a047d65bbfe5d43f3693f96dc5b6fcf2c',1,'monitorwindow.h']]],
  ['size_5fpercentage',['SIZE_PERCENTAGE',['../monitorwindow_8h.html#a7504381d97fa62409aca8a69f1fd4991',1,'monitorwindow.h']]],
  ['socket',['socket',['../class_monitor_window.html#adb49e06f2c7cda5eb72122185bbc7f8e',1,'MonitorWindow']]],
  ['status_5fdelimiter',['STATUS_DELIMITER',['../monitorwindow_8h.html#a3752bfe777d3eb9c1266d3a85bb4cedb',1,'monitorwindow.h']]]
];
