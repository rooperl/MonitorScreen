var searchData=
[
  ['text',['text',['../class_monitor_window.html#a928044153b7a85fb1408cbf3716f37ba',1,'MonitorWindow']]],
  ['text_5flength_5fmin',['TEXT_LENGTH_MIN',['../monitorwindow_8h.html#a86b373f36752beaa134c47628512e9a9',1,'monitorwindow.h']]],
  ['tick_5flength',['TICK_LENGTH',['../monitorwindow_8h.html#a6972c74913411bca990cd69190f929ce',1,'monitorwindow.h']]]
];
