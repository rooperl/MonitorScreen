var searchData=
[
  ['organization',['ORGANIZATION',['../monitorwindow_8h.html#a6400ed0fafb6e5946edb5a1940e7097b',1,'monitorwindow.h']]]
];
