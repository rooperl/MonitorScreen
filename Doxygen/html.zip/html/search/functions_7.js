var searchData=
[
  ['update',['update',['../class_monitor_window.html#ace98408b030d459c84fd874f5b69f93c',1,'MonitorWindow']]]
];
