var searchData=
[
  ['json_5fname',['JSON_NAME',['../monitorwindow_8h.html#a3808bcfb4f4de7a6cee81fe2d1e82a12',1,'monitorwindow.h']]],
  ['json_5ftime',['JSON_TIME',['../monitorwindow_8h.html#ab0e6e6856cfe18c70fba9676da517427',1,'monitorwindow.h']]],
  ['json_5fvalue',['JSON_VALUE',['../monitorwindow_8h.html#a75ea910c4b7fcf959a52c6512d08b8f8',1,'monitorwindow.h']]]
];
